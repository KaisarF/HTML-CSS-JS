$(document).ready(function(){
    $("#luffy").click(function(){
    $("#luffy-bio").slideToggle("slow");
    });
});

$(document).ready(function(){
    $("#zoro").click(function(){
    $("#zoro-bio").slideToggle("slow");
    });
});

$(document).ready(function(){
    $("#sanji").click(function(){
    $("#sanji-bio").slideToggle("slow");
    });
});

$(document).ready(function(){
    $("#chopper").click(function(){
    $("#chopper-bio").slideToggle("slow");
    });
});

$(document).ready(function(){
    $("#nami").click(function(){
    $("#nami-bio").slideToggle("slow");
    });
});

$(document).ready(function(){
    $("#brook").click(function(){
    $("#brook-bio").slideToggle("slow");
    });
});

$(document).ready(function(){
    $("#franky").click(function(){
    $("#franky-bio").slideToggle("slow");
    });
});

$(document).ready(function(){
    $("#robin").click(function(){
    $("#robin-bio").slideToggle("slow");
    });
});

$(document).ready(function(){
    $("#ussop").click(function(){
    $("#ussop-bio").slideToggle("slow");
    });
});

$(document).ready(function(){
    $("#jinbei").click(function(){
    $("#jinbei-bio").slideToggle("slow");
    });
});

